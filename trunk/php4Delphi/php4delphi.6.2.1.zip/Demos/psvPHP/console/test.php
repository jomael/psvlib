<?php  
 phpinfo();
?>

