<?
 $z =  $x + $y;
 phpinfo();
?>
