<?
 $z =  $x + $y;
 echo "Result " ;
 echo $z;
?>
