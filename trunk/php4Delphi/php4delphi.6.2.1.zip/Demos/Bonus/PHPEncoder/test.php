<?
 dl('phpencoder.dll');
 ex_dec();
?>
x`xafng !3